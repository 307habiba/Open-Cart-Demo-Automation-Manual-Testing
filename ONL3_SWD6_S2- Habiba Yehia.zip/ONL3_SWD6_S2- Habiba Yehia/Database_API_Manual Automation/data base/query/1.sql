use opencartdemo;
select *from oc_customer;
select *from oc_order;
