Select cart_id,session_id , product_id , quantity 
from oc_cart
Order by cart_id DESC;
SELECT quantity From oc_product Where product_id =41;
