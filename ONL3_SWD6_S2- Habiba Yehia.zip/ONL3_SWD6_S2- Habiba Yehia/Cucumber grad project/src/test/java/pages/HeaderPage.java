package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class HeaderPage extends BasePage {

    public HeaderPage(WebDriver driver) {
        super(driver);
    }

    private final By desktopsMenu = By.linkText("Desktops");
    private final By laptopsMenu = By.linkText("Laptops & Notebooks");
    private final By desktopsDropdown = By.xpath("//a[@class='nav-link dropdown-toggle' and text()='Desktops']");


    public void clickDesktops() {
        driver.findElement(desktopsMenu).click();
    }

    public void clickLaptops() {
        driver.findElement(laptopsMenu).click();
    }

    public void hoverDesktops() {
        WebElement desktops = driver.findElement(desktopsMenu);
        actions.moveToElement(desktops).perform();
    }

    public boolean desktopsDropdownVisible() {
        return driver.findElements(desktopsDropdown).size() > 0;
    }
}

