package pages;

import org.openqa.selenium.WebDriver;

public class ProductPage extends BasePage {

    public ProductPage(WebDriver driver) {
        super(driver);
    }

    public boolean isProductPage(String productName) {
        return getPageTitle().contains(productName);
    }
}
