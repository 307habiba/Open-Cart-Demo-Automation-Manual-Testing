package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class FooterPage extends BasePage {

    public FooterPage(WebDriver driver) {
        super(driver);
    }

    private final By contactUsLink = By.linkText("Contact Us");
    private final By aboutUsLink = By.linkText("About Us");
    private final By privacyLink = By.linkText("Privacy Policy");

    public void clickContactUs() {
        driver.findElement(contactUsLink).click();
    }
    public void clickAboutUs() {
        driver.findElement(aboutUsLink).click();
    }
    public void clickPrivacy() {
        driver.findElement(privacyLink).click();
    }


}
