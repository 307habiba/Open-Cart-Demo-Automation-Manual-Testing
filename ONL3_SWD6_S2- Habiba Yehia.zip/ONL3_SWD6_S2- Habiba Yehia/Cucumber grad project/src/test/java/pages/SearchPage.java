package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class SearchPage extends BasePage {

    public SearchPage(WebDriver driver) {
        super(driver);
    }

    private final By productTitles = By.cssSelector(".product-thumb h4 a");
    private final By noResultsMessage = By.cssSelector("#content p");

    public boolean productFound(String name) {
        return driver.findElements(productTitles)
                .stream()
                .anyMatch(e -> e.getText().contains(name));
    }

    public String getNoResultsMessage() {
        return driver.findElement(noResultsMessage).getText();
    }
}

