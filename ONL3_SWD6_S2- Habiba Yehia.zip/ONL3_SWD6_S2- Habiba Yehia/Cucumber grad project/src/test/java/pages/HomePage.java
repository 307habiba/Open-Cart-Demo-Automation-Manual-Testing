package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class HomePage extends BasePage {

    public HomePage(WebDriver driver) {
        super(driver);
    }

    // استخدام selectors أكثر مرونة
    private final By searchBox = By.cssSelector("input[name='search'], #search input");
    private final By searchButton = By.cssSelector("#search button, .btn-light, button[type='submit']");
    private final By iPhoneBanner = By.cssSelector("div#slideshow0 img, .swiper-slide img, .banner img");

    public void openHome() {
        driver.get("http://localhost/opencartsite/");
    }

    public void searchForProduct(String product) {
        try {
            WebElement searchInput = driver.findElement(searchBox);
            searchInput.clear();
            searchInput.sendKeys(product);

            WebElement searchBtn = driver.findElement(searchButton);
            searchBtn.click();
        } catch (NoSuchElementException e) {

            WebElement searchInput = driver.findElement(searchBox);
            searchInput.clear();
            searchInput.sendKeys(product);
            searchInput.sendKeys(Keys.ENTER);
        }
    }

    public void clickiPhoneBanner() {
        try {
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            WebElement banner = wait.until(ExpectedConditions.elementToBeClickable(iPhoneBanner));
            banner.click();
        } catch (NoSuchElementException e) {
            System.out.println("Banner not found with selector: " + iPhoneBanner);
            throw e;
        }
    }
}