package stepdef;
import io.cucumber.java.en.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import java.time.Duration;

public class WishlistSteps {

    WebDriver driver;
    WebDriverWait wait;

    @Given("user is on homepage")
    public void user_is_on_homepage() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://demo.opencart.com/en-gb/");
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
    }

    @When("user opens wishlist")
    public void user_opens_wishlist() {
        WebElement wishlistLink = wait.until(
                ExpectedConditions.visibilityOfElementLocated(By.id("wishlist-total")));
        wishlistLink.click();
    }

    @Then("wishlist should be empty")
    public void wishlist_should_be_empty() {
        WebElement emptyMessage = wait.until(
                ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#content p")));
        Assert.assertTrue(emptyMessage.getText().contains("Your wish list is empty"));
        driver.quit();
    }

    @When("user adds first product to wishlist")
    public void user_adds_first_product_to_wishlist() {
        By firstProduct = By.cssSelector(".product-layout .product-thumb a[href*='macbook']");
        WebElement product = wait.until(ExpectedConditions.elementToBeClickable(firstProduct));
        product.click();

        By wishlistBtn = By.cssSelector("button[aria-label='Add to Wish List']");
        WebElement wishlistButton = wait.until(ExpectedConditions.elementToBeClickable(wishlistBtn));
        wishlistButton.click();
    }

    @Then("wishlist should contain one product")
    public void wishlist_should_contain_one_product() {
        WebElement wishlistLink = wait.until(
                ExpectedConditions.visibilityOfElementLocated(By.id("wishlist-total")));
        wishlistLink.click();

        int productCount = driver.findElements(By.cssSelector(".table-responsive tbody tr")).size();
        Assert.assertEquals(productCount, 1, "Wishlist does not contain 1 product!");
        driver.quit();
    }

    @When("user removes product from wishlist")
    public void user_removes_product_from_wishlist() {
        WebElement wishlistLink = wait.until(
                ExpectedConditions.visibilityOfElementLocated(By.id("wishlist-total")));
        wishlistLink.click();

        By removeBtn = By.cssSelector("button[data-bs-original-title='Remove']");
        WebElement removeButton = wait.until(ExpectedConditions.elementToBeClickable(removeBtn));
        removeButton.click();

        wait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector(".table-responsive tbody tr")));
    }

    @Then("wishlist should be empty again")
    public void wishlist_should_be_empty_again() {
        WebElement emptyMessage = wait.until(
                ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#content p"))
        );
        Assert.assertTrue(emptyMessage.getText().contains("Your wish list is empty"));
        driver.quit();
    }
}
