package stepdef;

import io.cucumber.java.en.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import pages.HeaderPage;
import pages.HomePage;

import java.time.Duration;

public class HeaderSteps {

    HomePage home = new HomePage(Hooks.driver);
    HeaderPage header = new HeaderPage(Hooks.driver);

    @Given("I am on the Home page")
    public void i_am_on_home_page() {
        home.openHome();
    }

    @When("I click on the {string} menu")
    public void i_click_on_menu(String menuName) {
        switch (menuName) {
            case "Desktops":
                header.clickDesktops();
                break;
            case "Laptops & Notebooks":
                header.clickLaptops();
                break;
        }
    }
    @Then("I should be navigated to the Laptops & Notebooks page")
    public void i_should_be_navigated_to_laptops_notebooks_page() {
        Assert.assertTrue(Hooks.driver.getTitle().contains("Laptops") ||
                        Hooks.driver.getTitle().contains("Notebooks"),
                "Page title incorrect! Actual title: " + Hooks.driver.getTitle());
    }

    @Then("I should be navigated to the {string} category page")
    public void i_should_be_navigated_to_category_page(String pageName) {
        WebDriverWait wait = new WebDriverWait(Hooks.driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.titleContains(pageName));

        String actualTitle = Hooks.driver.getTitle();
        Assert.assertTrue(actualTitle.contains(pageName),
                "Page title incorrect! Expected to contain: " + pageName +
                        ", but actual title is: " + actualTitle);
    }
    @When("I hover on the {string} menu")
    public void i_hover_on_menu(String menuName) {
        if (menuName.equals("Desktops")) {
            header.hoverDesktops();
        }
    }

    @Then("I should see the Desktops dropdown options")
    public void desktops_dropdown_visible() {
        Assert.assertTrue(header.desktopsDropdownVisible(),
                "Dropdown NOT visible!");
    }
}
