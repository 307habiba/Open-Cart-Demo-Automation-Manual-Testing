package stepdef;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.time.Duration;
import java.util.List;

public class ShoppingCartSteps {


    WebDriver driver = Hooks.driver;

    // ================= Homepage =================
    @Given("the user opens the homepage")
    public void theUserOpensTheHomepage() {
        driver.get("http://localhost/opencartsite/");
    }

    // ================= Cart Page =================
    @When("the user opens the cart page")
    public void theUserOpensTheCartPage() {
        WebElement cartButton = driver.findElement(By.xpath("//button[i[@class='fa-solid fa-shopping-cart']]"));
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", cartButton);
    }

    @Then("the search input should be visible")
    public void theSearchInputShouldBeVisible() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement searchInput = wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("search")));
        Assert.assertTrue(searchInput.isDisplayed(), "Search input is not visible on the page");
    }

    // ================= Add Product =================
    @When("the user adds product {string} to the cart")
    public void theUserAddsProductToTheCart(String productName) {
        List<WebElement> addToCartButtons = driver.findElements(By.xpath("//button[i[@class='fa-solid fa-shopping-cart']]"));
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        for (WebElement cartButton : addToCartButtons) {
            wait.until(ExpectedConditions.elementToBeClickable(cartButton));
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", cartButton);
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", cartButton);
        }
    }

    @Then("the product image should be visible on the page")
    public void theProductImageShouldBeVisibleOnThePage() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
        List<WebElement> productImages = driver.findElements(
                By.xpath("//img[contains(@src,'apple_cinema_30') or contains(@src,'canon_eos_5d')]")
        );
        boolean imageVisible = productImages.stream().anyMatch(WebElement::isDisplayed);
        Assert.assertTrue(imageVisible, "Expected product image to be visible on the page");
    }

    // ================= Cart Validations =================
    @When("user clicks on the cart icon")
    public void userClicksOnCartIcon() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement cartIcon = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@title='Shopping Cart']")));
        cartIcon.click();
    }

    @Then("the cart dropdown should be visible")
    public void cartDropdownShouldBeVisible() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement cartDropdown = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.cssSelector("button.btn.btn-lg.btn-dark.dropdown-toggle")
        ));
        Assert.assertTrue(cartDropdown.isDisplayed(), "Cart dropdown is not visible");
    }

    // ================= Empty Cart Message =================
    @When("user removes all products from the cart")
    public void userRemovesAllProductsFromCart() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));


        List<WebElement> removeButtons = driver.findElements(By.cssSelector("button[data-original-title='Remove']"));
        while (!removeButtons.isEmpty()) {
            WebElement removeBtn = removeButtons.get(0);
            wait.until(ExpectedConditions.elementToBeClickable(removeBtn));
            removeBtn.click();


            wait.until(ExpectedConditions.stalenessOf(removeBtn));


            removeButtons = driver.findElements(By.cssSelector("button[data-original-title='Remove']"));
        }
    }


    @Then("the empty cart message should appear")
    public void emptyCartMessageShouldAppear() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement emptyMessage = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//button[contains(text(),'0 item(s)')]")
        ));


        String messageText = emptyMessage.getText();
        Assert.assertTrue(messageText.contains("0 item(s)"), "Empty cart message is not displayed");
        Assert.assertTrue(messageText.contains("$0.00"), "Empty cart total is not correct");
    }


    // ================= Continue Button =================
    @Then("the Continue button should be enabled")
    public void continueButtonShouldBeEnabled() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement continueButton = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("a.btn.btn-primary")));
        Assert.assertTrue(continueButton.isEnabled(), "Continue button is not enabled");
    }

    // ================= Remove Product =================
    @When("user removes a product from the shopping cart")
    public void userRemovesProductFromCart() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        List<WebElement> removeButtons = driver.findElements(By.cssSelector("button[data-original-title='Remove']"));
        if (!removeButtons.isEmpty()) {
            WebElement removeButton = removeButtons.get(0);
            wait.until(ExpectedConditions.elementToBeClickable(removeButton));
            removeButton.click();
            wait.until(ExpectedConditions.stalenessOf(removeButton));
        }
    }

    @Then("the product should be removed from the cart")
    public void productShouldBeRemovedFromCart() {
        List<WebElement> products = driver.findElements(By.cssSelector("td.text-start a"));
        Assert.assertTrue(products.isEmpty(), "Product is still in the cart");
    }
}
