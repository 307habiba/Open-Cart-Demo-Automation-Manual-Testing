package stepdef;

import io.cucumber.java.en.*;
import org.testng.Assert;
import pages.HomePage;
import pages.ProductPage;

public class HomeBannerSteps {

    HomePage home = new HomePage(Hooks.driver);
    ProductPage product = new ProductPage(Hooks.driver);

    @When("I click on the iPhone6 banner")
    public void i_click_banner() {
        home.clickiPhoneBanner();
    }

    @Then("I should be navigated to the iPhone6 product page")
    public void check_product_page() {
        Assert.assertTrue(product.isProductPage("iPhone"),
                "Not redirected to iPhone page!");
    }
}
