package stepdef;

import io.cucumber.java.en.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

import static org.junit.jupiter.api.Assertions.assertEquals;  // <-- JUnit 5

public class VerifyProductNameSteps {

    WebDriver driver;
    WebDriverWait wait;

    @Given("user is on the main page")
    public void user_is_on_the_main_page() {
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--remote-allow-origins=*");
        driver = new ChromeDriver(options);
        driver.manage().window().maximize();
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        driver.get("http://localhost/opencartdemo/");
    }

    @When("user clicks on the {string} product image")
    public void user_clicks_on_the_product_image(String productName) {
        WebElement productImage = driver.findElement(
                By.cssSelector("img[title='" + productName + "']")
        );
        productImage.click();
    }

    @Then("user should see the product name as {string}")
    public void user_should_see_the_product_name_as(String expectedName) {
        WebElement productDetailName = wait.until(
                ExpectedConditions.visibilityOfElementLocated(By.cssSelector("h1"))
        );

        String actualName = productDetailName.getText();
        System.out.println("Product name on detail page: " + actualName);

        assertEquals(expectedName, actualName, "Product name does not match!"); // <-- fixed

        //driver.quit();
    }
}
