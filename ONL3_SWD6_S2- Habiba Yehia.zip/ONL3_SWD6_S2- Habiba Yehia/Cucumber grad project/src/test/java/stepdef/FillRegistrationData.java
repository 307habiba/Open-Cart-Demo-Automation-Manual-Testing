package stepdef;

import io.cucumber.java.en.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import io.github.bonigarcia.wdm.WebDriverManager;

import java.time.Duration;

public class FillRegistrationData {

    WebDriver driver;
    WebDriverWait wait;
    Actions actions;

    @Given("user is on the registration page")
    public void user_is_on_registration_page() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("http://localhost/opencartdemo/index.php?route=account/register");

        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        actions = new Actions(driver);
    }

    @When("user fills registration form without {string}")
    public void user_fills_registration_form_without(String field) {
        if (!field.equalsIgnoreCase("first name"))
            driver.findElement(By.id("input-firstname")).sendKeys("first");
        if (!field.equalsIgnoreCase("last name"))
            driver.findElement(By.id("input-lastname")).sendKeys("last");
        if (!field.equalsIgnoreCase("email"))
            driver.findElement(By.id("input-email")).sendKeys("ha@gmail.com");
        if (!field.equalsIgnoreCase("password"))
            driver.findElement(By.id("input-password")).sendKeys("Test@1234");

        // Agree checkbox (skip if testing privacy policy scenario)
        if (!field.equalsIgnoreCase("privacy")) {
            WebElement agreeCheckbox = driver.findElement(By.name("agree"));
            actions.moveToElement(agreeCheckbox).click().perform();
        }

        // Click Continue button
        WebElement continueButtonForm = driver.findElement(By.cssSelector("button.btn.btn-primary"));
        actions.moveToElement(continueButtonForm).click().perform();
    }

    @When("user fills registration form with valid data")
    public void user_fills_registration_form_with_valid_data() {
        driver.findElement(By.id("input-firstname")).sendKeys("FirstName");
        driver.findElement(By.id("input-lastname")).sendKeys("LastName");
        driver.findElement(By.id("input-email")).sendKeys("validemail@example.com");
        driver.findElement(By.id("input-password")).sendKeys("ValidPass@123");

        // Agree to Privacy Policy
        WebElement agreeCheckbox = driver.findElement(By.name("agree"));
        actions.moveToElement(agreeCheckbox).click().perform();

        // Click Continue button
        WebElement continueButtonForm = driver.findElement(By.cssSelector("button.btn.btn-primary"));
        actions.moveToElement(continueButtonForm).click().perform();
    }

    @Then("user should see registration success")
    public void user_should_see_registration_success() {
        // Wait for the Continue button on success page
        WebElement continueButtonLink = wait.until(
                ExpectedConditions.elementToBeClickable(By.cssSelector("a.btn.btn-primary"))
        );
        System.out.println("Registration success page displayed.");

        // Wait 3 seconds to view the result
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        driver.quit();
    }

    @Then("user should see error for missing {string}")
    public void user_should_see_error_for_missing_field(String field) {
        WebElement errorElement = null;
        switch (field.toLowerCase()) {
            case "first name":
                errorElement = driver.findElement(By.cssSelector("input#input-firstname + div.text-danger"));
                break;
            case "last name":
                errorElement = driver.findElement(By.cssSelector("input#input-lastname + div.text-danger"));
                break;
            case "email":
                errorElement = driver.findElement(By.cssSelector("input#input-email + div.text-danger"));
                break;
            case "password":
                errorElement = driver.findElement(By.cssSelector("input#input-password + div.text-danger"));
                break;
            case "privacy":
                errorElement = driver.findElement(By.cssSelector("div.alert.alert-danger"));
                break;
        }
        wait.until(ExpectedConditions.visibilityOf(errorElement));
        System.out.println("Error message displayed: " + errorElement.getText());

        // Wait 3 seconds before quitting
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        driver.quit();
    }
}
