package stepdef;

import io.cucumber.java.en.*;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import pages.FooterPage;
import pages.HomePage;
import java.time.Duration;

import static stepdef.Hooks.driver;

public class FooterSteps {

    HomePage home = new HomePage(driver);
    FooterPage footer = new FooterPage(driver);

    @When("I click on the {string} footer link")
    public void i_click_footer_link(String linkName) {
        By link;
        switch (linkName) {
            case "Contact Us":
                link = By.linkText("Contact Us");
                break;
            case "About Us":
                link = By.linkText("About Us");
                break;
            case "Privacy Policy":
                link = By.linkText("Privacy Policy");
                break;
            default:
                throw new RuntimeException("Unknown footer link: " + linkName);
        }

        // Scroll to bottom of page to ensure footer is visible
        ((JavascriptExecutor) driver).executeScript("window.scrollTo(0, document.body.scrollHeight);");

        // Wait a bit for scroll to complete
        try { Thread.sleep(1000); } catch (InterruptedException e) {}

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement element = wait.until(ExpectedConditions.elementToBeClickable(link));

        // Use JavaScript click to avoid interception
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);

        System.out.println("Clicked footer link: " + linkName + " | Title now: " + driver.getTitle());
    }

    @Then("I should be navigated to the {string} page")
    public void i_should_be_navigated_to_page(String expected) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
        wait.until(ExpectedConditions.titleContains(expected));

        System.out.println("Final title = " + driver.getTitle());
        Assert.assertTrue(driver.getTitle().contains(expected));
    }

}
