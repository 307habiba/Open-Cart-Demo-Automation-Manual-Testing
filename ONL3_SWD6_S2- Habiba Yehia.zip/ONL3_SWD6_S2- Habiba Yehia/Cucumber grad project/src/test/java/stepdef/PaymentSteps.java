package stepdef;

import io.cucumber.java.en.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.chrome.ChromeDriver;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.testng.Assert;

import java.time.Duration;

public class PaymentSteps {

    WebDriver driver;
    WebDriverWait wait;

    @Given("product {string} is in cart")
    public void product_in_cart(String product) {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://demo.opencart.com/index.php?route=product/search&search=" + product);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".button-group button[aria-label='Add to Cart']"))).click();
    }

    @When("user selects existing address")
    public void select_existing_address() {
        wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("input[value='existing']"))).click();
        wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("input[name='address_id']"))).click();
        driver.findElement(By.id("button-payment-address")).click();
    }

    @When("selects shipping method {string}")
    public void select_shipping_method(String method) {
        WebElement shipping = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@name='shipping_method' and @value='flat.flat']")));
        shipping.click();
        driver.findElement(By.id("button-shipping-method")).click();
    }

    @When("leaves shipping method empty")
    public void leave_shipping_method_empty() {
        driver.findElement(By.id("button-shipping-method")).click();
    }

    @When("selects payment method {string}")
    public void select_payment_method(String method) {
        WebElement payment = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@name='payment_method' and @value='cod']")));
        payment.click();
        driver.findElement(By.id("button-payment-method")).click();
    }

    @When("leaves payment method empty")
    public void leave_payment_method_empty() {
        driver.findElement(By.id("button-payment-method")).click();
    }

    @When("clicks confirm order")
    public void click_confirm_order() {
        driver.findElement(By.id("button-confirm")).click();
    }

    @Then("order should be placed successfully")
    public void verify_order_success() {
        String message = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#content h1"))).getText();
        Assert.assertTrue(message.contains("Your order has been placed!"));
        driver.quit();
    }

    @Then("error message {string} is displayed")
    public void verify_payment_error(String message) {
        String text = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".text-danger"))).getText();
        Assert.assertTrue(text.contains(message));
        driver.quit();
    }
}