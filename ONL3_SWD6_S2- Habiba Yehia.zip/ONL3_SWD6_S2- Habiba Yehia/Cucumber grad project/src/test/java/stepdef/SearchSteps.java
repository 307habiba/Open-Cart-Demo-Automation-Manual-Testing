package stepdef;

import io.cucumber.java.en.*;
import org.testng.Assert;
import pages.HomePage;
import pages.SearchPage;

public class SearchSteps {

    HomePage home = new HomePage(Hooks.driver);
    SearchPage searchPage = new SearchPage(Hooks.driver);

    @When("I search for a valid product {string}")
    public void search_valid(String product) {
        home.searchForProduct(product);
    }

    @Then("I should see the product {string} in results")
    public void verify_product(String product) {
        Assert.assertTrue(searchPage.productFound(product),
                "Product not found!");
    }

    @When("I search for an invalid product {string}")
    public void search_invalid(String text) {
        home.searchForProduct(text);
    }

    @Then("I should see a message saying {string}")
    public void verify_no_results(String expected) {
        Assert.assertEquals(searchPage.getNoResultsMessage(), expected);
    }
}
