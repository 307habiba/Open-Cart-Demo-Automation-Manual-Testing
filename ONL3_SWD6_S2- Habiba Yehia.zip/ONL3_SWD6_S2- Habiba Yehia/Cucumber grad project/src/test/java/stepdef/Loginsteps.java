package stepdef;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import java.time.Duration;
import org.openqa.selenium.By;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import io.cucumber.java.PendingException;
import java.time.Duration;

public class Loginsteps {
    WebDriver driver;
    WebDriverWait wait;
    Actions actions;

    @Given("user is in login page")
    public void user_is_in_login_page() {
        WebDriverManager.chromedriver().setup();
        this.driver = new ChromeDriver();
        this.driver.manage().window().maximize();
        this.driver.get("https://demo.opencart.com/en-gb?route=account/login");
        this.wait = new WebDriverWait(this.driver, Duration.ofSeconds(10));
        this.actions = new Actions(this.driver);
    }
// Scenario1
    @When("user enter valid email and valid password")
    public void user_enter_valid_email_and_valid_password() {
        WebElement emailField = this.driver.findElement(By.id("input-email"));
        WebElement passwordField = this.driver.findElement(By.id("input-password"));
        WebElement loginButton = this.driver.findElement(By.cssSelector("button[type='submit']"));

        emailField.sendKeys("m2@gmail.com");
        passwordField.sendKeys("0000");

        this.actions.moveToElement(loginButton).click().perform();
    }

    @Then("no error message will be display")
    public void no_error_message_will_be_display() {
        boolean hasError = this.driver.getPageSource().contains("Warning");

        if (hasError) {
            throw new AssertionError("Login failed: Error message displayed!");
        }

        this.driver.quit();

    }
    // Scenario2
    @When("user enter invalid email and valid password")
    public void user_enter_invalid_email_and_valid_password() {
        WebElement emailField = driver.findElement(By.id("input-email"));
        WebElement passwordField = driver.findElement(By.id("input-password"));
        WebElement loginButton = driver.findElement(By.cssSelector("button[type='submit']"));

        emailField.sendKeys("mmm@gmail.com");
        passwordField.sendKeys("0000");

        actions.moveToElement(loginButton).click().perform();
    }

// Scenario3
@When("user enter valid email and invalid password")
public void user_enter_valid_email_and_invalid_password() {
    WebElement emailField = driver.findElement(By.id("input-email"));
    WebElement passwordField = driver.findElement(By.id("input-password"));
    WebElement loginButton = driver.findElement(By.cssSelector("button[type='submit']"));

    emailField.sendKeys("m2@gmail.com");
    passwordField.sendKeys("1234");

    actions.moveToElement(loginButton).click().perform();
}

// Scenario4
@When("user enter invalid email and invalid password")
public void user_enter_invalid_email_and_invalid_password() {
    driver.findElement(By.id("input-email")).sendKeys("mmm@gmail.com");
    driver.findElement(By.id("input-password")).sendKeys("1234");
    driver.findElement(By.cssSelector("button[type='submit']")).click();
}
// Scenario5
@When("user leave email and password empty")
public void user_leave_email_and_password_empty() {
    WebElement loginButton = driver.findElement(By.cssSelector("button[type='submit']"));
    loginButton.click();
}
// Scenario6
@When("user enter with invalid email format")
public void user_enter_with_invalid_email_format() {
    WebElement emailField = driver.findElement(By.id("input-email"));
    WebElement passwordField = driver.findElement(By.id("input-password"));
    WebElement loginButton = driver.findElement(By.cssSelector("button[type='submit']"));

    emailField.sendKeys("m2@@gmail");
    passwordField.sendKeys("0000");
    loginButton.click();
}
// Scenario7
@When("user leave email empty and Correct password")
public void user_leave_email_empty_and_correct_password() {
    WebElement emailField = driver.findElement(By.id("input-email"));
    WebElement passwordField = driver.findElement(By.id("input-password"));
    WebElement loginButton = driver.findElement(By.cssSelector("button[type='submit']"));

    passwordField.sendKeys("0000");
    loginButton.click();
}
// Scenario8
@When("user enter valid email and leave empty password")
public void user_enter_valid_email_and_leave_empty_password() {
    WebElement emailField = driver.findElement(By.id("input-email"));
    WebElement passwordField = driver.findElement(By.id("input-password"));
    WebElement loginButton = driver.findElement(By.cssSelector("button[type='submit']"));

    emailField.sendKeys("m2@gmail.com");
    loginButton.click();
}
    @Then("error message will be displayed")
    public void error_message_will_be_displayed() {
        boolean hasError = driver.getPageSource().contains("Warning: No match for E-Mail Address and/or Password.");

        if (!hasError) {
            throw new AssertionError("Expected error message not displayed!");
        }
        driver.quit();
    }

// Scenario9
@When("user enter invalid email for Forgotten Password")
public void user_enter_invalid_email_for_forgotten_password() {
    driver.findElement(By.linkText("Forgotten Password")).click();

    WebElement emailField = driver.findElement(By.id("input-email"));
    WebElement continueButton = driver.findElement(By.cssSelector("input[type='submit']"));

    emailField.sendKeys("mmm@gmail.com");
    continueButton.click();
}

    @Then("error message will be displayed for password reset with invalid email")
    public void error_message_will_be_displayed_for_password_reset_with_invalid_email() {
        String pageSource = driver.getPageSource();

        if (!pageSource.contains("Warning: The E-Mail Address was not found in our records!") &&
                pageSource.contains("Success: Your password has been successfully updated.")) {
            throw new AssertionError(
                    "BUG FOUND: System should show error message for invalid email but shows success message instead."
            );
        }
        driver.quit();
    }


// Scenario10
@When("user enter valid email for Forgotten Password")
public void user_enter_valid_email_for_forgotten_password() {
    driver.findElement(By.linkText("Forgotten Password")).click();

    WebElement emailField = driver.findElement(By.id("input-email"));
    WebElement continueButton = driver.findElement(By.cssSelector("input[type='submit']"));

    emailField.sendKeys("m2@gmail.com");
    continueButton.click();
}

    @Then("error message will be displayed for password reset with valid email")
    public void error_message_will_be_displayed_for_password_reset_with_valid_email() {
        String pageSource = driver.getPageSource();

        if (!pageSource.contains("Password Reset") && pageSource.contains("Success: Your password has been successfully updated.")) {
            throw new AssertionError(
                    "BUG FOUND: System should navigate to password reset page but only shows success message."
            );
        }
        driver.quit();
    }

// Scenario11
@When("user enter invalid email format for Forgotten Password")
public void user_enter_invalid_email_format_for_forgotten_password() {
    driver.findElement(By.linkText("Forgotten Password")).click();

    WebElement emailField = driver.findElement(By.id("input-email"));
    WebElement continueButton = driver.findElement(By.cssSelector("input[type='submit']"));

    emailField.sendKeys("invalidemail");
    continueButton.click();
}

    @Then("error message will be displayed for invalid email format")
    public void error_message_will_be_displayed_for_invalid_email_format() {
        String pageSource = driver.getPageSource();

        if (!pageSource.contains("Warning: The E-Mail Address was not found in our records!")) {
            throw new AssertionError(
                    "Expected error message not displayed for invalid email format."
            );
        }
        driver.quit();
    }

}